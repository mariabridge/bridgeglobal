
This patch includes a bug fix on stock update when installed on magento 1.9


How to instaal this patch
------------------------
Directly upload the 'app' directory and the contants to magento root directory.